export declare const createTransaction: (req: any, res: any) => Promise<any>;
export declare const getAccountBalance: (req: any, res: any) => Promise<any>;
export declare const getAccounts: (req: any, res: any) => Promise<any>;
export declare const getTransactionHistory: (req: any, res: any) => Promise<any>;
export declare const getTrialBalance: (req: any, res: any) => Promise<any>;
export declare const getAuditTrail: (req: any, res: any) => Promise<any>;
//# sourceMappingURL=ledger.d.ts.map