export const globalErrorHandler = (err, req, res, next) => {
    console.error("Ledger Service Error:", err);
    res.status(500).json({
        success: false,
        error: "Internal server error",
        timestamp: new Date().toISOString(),
        service: "ledger-service"
    });
};
export const globalNotFoundHandler = (req, res, next) => {
    res.status(404).json({
        success: false,
        error: "Route not found",
        timestamp: new Date().toISOString(),
        service: "ledger-service",
        path: req.originalUrl
    });
};
//# sourceMappingURL=common.js.map