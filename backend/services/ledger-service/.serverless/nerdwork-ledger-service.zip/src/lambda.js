import serverless from 'serverless-http';
import { app } from './index.js';
export const handler = serverless(app, {
    request: (request, event, context) => {
        console.log('Ledger Service Request:', {
            method: request.method,
            path: request.path,
            headers: request.headers,
        });
    },
    response: (response, request, event, context) => {
        console.log('Ledger Service Response:', {
            statusCode: response.statusCode,
            headers: response.headers,
        });
    },
});
//# sourceMappingURL=lambda.js.map